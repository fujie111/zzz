function rua(){
	alert("asdasd");
	var a=document.getElementById("A").getElementsByTagName("a")
	alert(a.innerHTML);
}
